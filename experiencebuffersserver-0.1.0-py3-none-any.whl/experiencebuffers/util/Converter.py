'''
Created on Nov 12, 2025

@author: Lamar Gardere
'''
import os
import shutil
import subprocess
import logging

from experiencebuffers.util.Tools import Tools
from experiencebuffers.util.Standards import Standards

logger=logging.getLogger(__name__)


class Converter:

    def __init__(self,path=None):
        self.verbose=False

        self.setFFMPEGPath(path)
        self.setStreamingServerPath(Standards.BIN_DIR+"MediaMTX")

        self.transferPort=1935
        self.streamPort=8888
        self.streamLocation="/live/stream"
        self.streamProcess=None
        self.streamServer=None

    #-----------------------------------------------------------------
    def setVerbose(self,verbose):
        self.verbose=verbose

    #-----------------------------------------------------------------
    def setFFMPEGPath(self,path=None):
        self.ffmpegPath=self.getAppPath("ffmpeg",path)
        self.foundFFMPEG=Tools.exists(self.ffmpegPath)

    #-----------------------------------------------------------------
    def setStreamingServerPath(self,path=None):
        self.mediaMTXPath=self.getAppPath("mediamtx",path)
        self.foundMediaMTX=Tools.exists(self.mediaMTXPath)

    #-----------------------------------------------------------------
    def getAppPath(self,app,path=None):
        if path:
            result=Tools.validateDir(path,Standards.BIN_DIR)+(f"{app}.exe" if Tools.getPlatform()=="windows" else app)
        elif shutil.which(app):
            result=shutil.which(app)
        else:
            result=Tools.validateDir(Standards.BIN_DIR)+(f"{app}.exe" if Tools.getPlatform()=="windows" else app)

        return result

    #-----------------------------------------------------------------
    def run(self,cmd,stdout=None,stderr=None,text=False):
        if Tools.getPlatform()=="windows":
            result=subprocess.run(cmd,
                   creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS,
                   stdout=stdout if stdout else None if self.verbose else subprocess.DEVNULL,
                   stderr=stderr if stderr else None if self.verbose else subprocess.DEVNULL,
                   text=text,
                   check=True
                   )
        else:

            def lowPriority():
                os.nice(10)  #@UndefinedVariable

            result=subprocess.run(cmd,
                   preexec_fn=lowPriority,
                   stdout=stdout if stdout else None if self.verbose else subprocess.DEVNULL,
                   stderr=stderr if stderr else None if self.verbose else subprocess.DEVNULL,
                   text=text,
                   check=True
                   )

        return result

    #-----------------------------------------------------------------
    def checkFFMPEG(self,requiredMods=None):
        #requiredMods: list of strings like ["libx264", "aac"]
        result=True

        if self.foundFFMPEG:
            try:
                self.run([self.ffmpegPath,"-version"],subprocess.PIPE,subprocess.PIPE,text=True)

                if requiredMods:
                    output=self.run([self.ffmpegPath,"-codecs"],subprocess.PIPE,subprocess.PIPE,text=True)

                    codecs=output.stdout
                    for mod in requiredMods:
                        if mod not in codecs:
                            print(f"FFmpeg missing required module: {mod}")
                            result=False
                            break

            except Exception as e:
                print(f"FFmpeg check failed: {e}")
                result=False
        else:
            print(f"FFmpeg not found at {self.ffmpegPath}")
            result=False

        return result

    #-----------------------------------------------------------------
    # Uses FFMPEG to merge audio and video tracks.
    # inputFiles: dict of services and associated file names an codecs
    # outputName: name of resulting file after merge operation
    # returns boolean
    def mergeAudioVideo(self,inputFiles,outputFile,vCodec=None,aCodec=None):
        af=inputFiles["audio"]
        vf=inputFiles["video"]
        tmpOutputFile="/temp_".join(outputFile.rsplit("/",1))

        codecs=[]
        codecs.extend([str(vCodec).lower()] if vCodec else [])
        codecs.extend([str(aCodec).lower()] if aCodec else [])

        if result:=self.checkFFMPEG(codecs):
            cmd=[self.ffmpegPath]
            cmd.extend(["-y","-i",vf,"-i",af])
            cmd.extend(["-c:v",str(vCodec).lower()] if vCodec else [])
            cmd.extend(["-c:a",str(aCodec).lower()] if aCodec else [])
            cmd.extend([tmpOutputFile])

            try:
                self.run(cmd)
                if result:=(Tools.exists(tmpOutputFile) and Tools.getFileSize(tmpOutputFile)>0):
                    os.replace(tmpOutputFile,outputFile)
            except:
                result=False

        return result

    #-----------------------------------------------------------------
    # Uses FFMPEG to convert media
    # sourceFiles: dict of services and associated file names an codecs
    # outputName: name of resulting file after merge operation
    # returns boolean
    def convert(self,inputFile,outputFile,vCodec=None,aCodec=None):
        tmpOutputFile="/temp_".join(outputFile.rsplit("/",1))

        codecs=[]
        codecs.extend([str(vCodec).lower()] if vCodec else [])
        codecs.extend([str(aCodec).lower()] if aCodec else [])

        if result:=self.checkFFMPEG(codecs):
            cmd=[self.ffmpegPath]
            cmd.extend(["-y","-i",inputFile])
            cmd.extend(["-c:v",str(vCodec).lower()] if vCodec else [])
            cmd.extend(["-c:a",str(aCodec).lower()] if aCodec else [])
            cmd.extend([tmpOutputFile])

            try:
                self.run(cmd)
                if result:=(Tools.exists(tmpOutputFile) and Tools.getFileSize(tmpOutputFile)>0):
                    os.replace(tmpOutputFile,outputFile)
            except:
                result=False

        return result

    #-----------------------------------------------------------------
    def closeProcess(self,process):
        if process and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=5)
            except:
                process.kill()

    #-----------------------------------------------------------------
    def startRTMPServer(self):
        if not Tools.isLocalPortInUse(self.transferPort):
            self.streamServer=subprocess.Popen(self.mediaMTXPath,
                                               cwd=Tools.removefile(self.mediaMTXPath),
                                               stdout=None if self.verbose else subprocess.DEVNULL,
                                               stderr=None if self.verbose else subprocess.DEVNULL
                                               )
            Tools.waitForLocalPort(self.transferPort)
            if Tools.isLocalPortInUse(self.transferPort):
                print(f"RTMP Server was successfully started.")
            else:
                print(f"RTMP Server failed to start.")
        else:
            print(f"Port {self.transferPort} already in use.")

    #-----------------------------------------------------------------
    def stopRTMPServer(self):
        self.closeProcess(self.streamServer)
        self.streamServer=None

    #-----------------------------------------------------------------
    def openStream(self,file=None,width=None,height=None,fps=None,depth=None):
        if not self.streamProcess:
            cmd=[self.ffmpegPath]

            if file:
                cmd.extend(["-re","-i",file])
            else:
                cmd.extend([
                    "-y",
                    "-f","rawvideo",
                    "-pix_fmt",str(depth) if depth else "bgr24",
                    "-s",f"{width}x{height}" if width and height else "640x480",
                    "-r",str(fps) if fps else "15",
                    "-i","-"
                ])

            cmd.extend([
                "-c:v","libx264",
                "-g",str(fps) if fps else "15",
                "-keyint_min",str(fps) if fps else "15",
                "-preset","ultrafast",
                "-c:a","aac",
                "-f","flv",
                f"rtmp://localhost:{self.transferPort}{self.streamLocation}"
            ])

            try:
                if self.verbose:
                    self.streamProcess=subprocess.Popen(cmd) if file else subprocess.Popen(cmd,stdin=subprocess.PIPE)
                else:
                    self.streamProcess=subprocess.Popen(cmd) if file else subprocess.Popen(
                                        cmd,stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)

                print(f"Streaming to {self.getStreamURL()}")
            except:
                Tools.printStackTrace()
                self.closeStream()
                print(f"Opening stream to {self.getStreamURL()} failed")

        return self.streamProcess

    #-----------------------------------------------------------------
    def getStream(self):
        return self.streamProcess

    #-----------------------------------------------------------------
    def getStreamURL(self,ip=None):
        return f"http://{ip if ip else 'localhost'}:{self.streamPort}{self.streamLocation}"

    #-----------------------------------------------------------------
    def writeToStream(self,frame):
        try:
            if self.streamProcess:
                self.streamProcess.stdin.write(frame)

        except Exception as e:
            self.streamProcess=None
            Tools.printStackTrace()
            print(f"Stream to {self.getStreamURL()} has failed: {str(e)}")

    #-----------------------------------------------------------------
    def closeStream(self):
        self.closeProcess(self.streamProcess)
        self.streamProcess=None
